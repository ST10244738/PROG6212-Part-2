﻿namespace POE_part2
{
    public class connection
    {
        //return connection string
        public string Connecting()
        { 
            //then return the connection
            return "Data Source=(localdb)\\demo_p2;Initial Catalog=demo_db;";
        }

    }
}
